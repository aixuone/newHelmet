layui.define(function(exports){
  //do something
  
  exports('demo', function(){
    alert('Hello World!');
  });
});